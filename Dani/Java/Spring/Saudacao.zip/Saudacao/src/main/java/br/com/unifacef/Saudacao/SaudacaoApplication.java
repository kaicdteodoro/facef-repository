package br.com.unifacef.Saudacao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaudacaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaudacaoApplication.class, args);
	}

}
